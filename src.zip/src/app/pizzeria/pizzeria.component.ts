import { Component, Input } from '@angular/core';
import { type Pizza } from './pizza/pizza.model';
import { ListaPizzeComponent } from './lista-pizze/lista-pizze.component';
import { PizzaComponent } from './pizza/pizza.component';

@Component({
  selector: 'app-pizzeria',
  standalone: true,
  imports: [ListaPizzeComponent, PizzaComponent],
  templateUrl: './pizzeria.component.html',
  styleUrl: './pizzeria.component.css',
})
export class PizzeriaComponent {
  foo!: Pizza;

  onSelectedPizza(pizza: Pizza) {
    this.foo = pizza;
  }
}
