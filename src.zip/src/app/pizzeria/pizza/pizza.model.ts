export interface Pizza {
  id: number;
  nomePizza: string;
  prezzo: number;
  ingredienti: string[];
  disponibilita: boolean;
}
